import Link from "next/link";
import { navLinks } from "./Header";

export default function Footer() {
  return (
    <footer className="mt-24 border-t border-black/5">
      <div className="mx-auto max-w-6xl px-5 py-10">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <p className="font-bold">genz_looks</p>
            <p className="text-sm text-neutral-500">Things worth buying.</p>
          </div>
          <nav className="flex gap-6 text-sm text-neutral-600">
            {navLinks.map((l) => (
              <Link key={l.label} href={l.href} className="hover:text-black">
                {l.label}
              </Link>
            ))}
          </nav>
        </div>
        <p className="mt-8 max-w-xl text-xs leading-relaxed text-neutral-400">
          Some links may be affiliate links. If you purchase through them, I may earn a
          commission at no additional cost to you.
        </p>
      </div>
    </footer>
  );
}
