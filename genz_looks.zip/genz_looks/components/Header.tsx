"use client";

import Link from "next/link";
import { useState } from "react";

export const navLinks = [
  { label: "Home", href: "/" },
  { label: "Finds", href: "/#finds" },
  { label: "Channel", href: "https://www.youtube.com" }, // TODO: your channel URL
  { label: "About", href: "/#about" },
];

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-20 border-b border-black/5 bg-canvas/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
        <Link href="/" className="text-lg font-bold tracking-tight">
          genz_looks
        </Link>

        <nav className="hidden gap-7 text-sm text-neutral-600 md:flex">
          {navLinks.map((l) => (
            <Link key={l.label} href={l.href} className="hover:text-black">
              {l.label}
            </Link>
          ))}
        </nav>

        <button
          className="rounded-full border border-black/10 px-4 py-1.5 text-sm md:hidden"
          onClick={() => setOpen(!open)}
          aria-expanded={open}
          aria-label="Toggle menu"
        >
          {open ? "Close" : "Menu"}
        </button>
      </div>

      {open && (
        <nav className="flex flex-col border-t border-black/5 px-5 py-2 md:hidden">
          {navLinks.map((l) => (
            <Link
              key={l.label}
              href={l.href}
              onClick={() => setOpen(false)}
              className="py-3 text-neutral-700"
            >
              {l.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
