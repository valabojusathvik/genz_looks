"use client";

import { useState } from "react";
import ProductCard from "@/components/ProductCard";
import { useProducts } from "@/lib/useProducts";
import type { Platform, Product } from "@/data/products";

const empty = {
  name: "",
  price: "",
  platform: "Amazon" as Platform,
  rating: "",
  image: "",
  description: "",
  affiliateUrl: "",
};

function isUrl(value: string) {
  try {
    const u = new URL(value);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

const input =
  "mt-1 w-full rounded-xl border border-black/10 bg-white px-4 py-3 text-sm outline-none focus:border-black";

export default function AdminPage() {
  const { addProduct } = useProducts();
  const [form, setForm] = useState(empty);
  const [error, setError] = useState("");
  const [created, setCreated] = useState<Product | null>(null);

  function set(field: keyof typeof empty, value: string) {
    setForm({ ...form, [field]: value });
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setCreated(null);

    const rating = Number(form.rating);
    if (!form.name.trim() || !form.price.trim() || !form.description.trim()) {
      return setError("Please fill in name, price and description.");
    }
    if (!form.rating || isNaN(rating) || rating < 0 || rating > 5) {
      return setError("Rating must be a number between 0 and 5.");
    }
    if (!isUrl(form.image)) return setError("Enter a valid image URL (starting with https://).");
    if (!isUrl(form.affiliateUrl)) {
      return setError("Enter a valid affiliate URL (starting with https://).");
    }

    setError("");
    const product = addProduct({
      name: form.name.trim(),
      price: form.price.trim(),
      platform: form.platform,
      rating,
      image: form.image.trim(),
      description: form.description.trim(),
      affiliateUrl: form.affiliateUrl.trim(),
    });
    setCreated(product);
    setForm(empty);
  }

  return (
    <div className="grid gap-12 py-12 lg:grid-cols-2">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Add a product</h1>
        <p className="mt-2 text-sm text-neutral-500">
          Products are saved in this browser only. To make one permanent for everyone, add it to{" "}
          <code>data/products.ts</code>.
        </p>

        <form onSubmit={submit} className="mt-8 space-y-5">
          <label className="block text-sm font-medium">
            Product name
            <input className={input} placeholder="Sony Wireless Headphones" value={form.name} onChange={(e) => set("name", e.target.value)} />
          </label>
          <div className="grid grid-cols-2 gap-4">
            <label className="block text-sm font-medium">
              Price
              <input className={input} placeholder="₹4,999" value={form.price} onChange={(e) => set("price", e.target.value)} />
            </label>
            <label className="block text-sm font-medium">
              Rating (0–5)
              <input className={input} placeholder="4.5" inputMode="decimal" value={form.rating} onChange={(e) => set("rating", e.target.value)} />
            </label>
          </div>
          <label className="block text-sm font-medium">
            Marketplace
            <select className={input} value={form.platform} onChange={(e) => set("platform", e.target.value)}>
              <option>Amazon</option>
              <option>Flipkart</option>
              <option>Meesho</option>
            </select>
          </label>
          <label className="block text-sm font-medium">
            Product image URL
            <input className={input} placeholder="https://example.com/product.jpg" value={form.image} onChange={(e) => set("image", e.target.value)} />
          </label>
          <label className="block text-sm font-medium">
            Description
            <textarea className={input} rows={3} value={form.description} onChange={(e) => set("description", e.target.value)} />
          </label>
          <label className="block text-sm font-medium">
            Affiliate URL
            <input className={input} placeholder="https://..." value={form.affiliateUrl} onChange={(e) => set("affiliateUrl", e.target.value)} />
          </label>

          {error && <p className="text-sm text-red-600">{error}</p>}

          <button type="submit" className="rounded-full bg-black px-6 py-3 text-sm font-medium text-white transition hover:bg-neutral-800">
            Publish product →
          </button>
        </form>
      </div>

      <div>
        {created && (
          <>
            <p className="rounded-xl bg-accent/10 px-4 py-3 text-sm text-accent">
              Product published. It now appears on the homepage.
            </p>
            <div className="mt-6 max-w-sm">
              <ProductCard product={created} />
            </div>
          </>
        )}
      </div>
    </div>
  );
}
