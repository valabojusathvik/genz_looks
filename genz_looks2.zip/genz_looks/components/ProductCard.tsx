import Link from "next/link";
import type { Product } from "@/data/products";

export default function ProductCard({ product }: { product: Product }) {
  return (
    <Link
      href={`/products/${product.id}`}
      className="group block overflow-hidden rounded-card border border-black/5 bg-white transition hover:border-black/15"
    >
      <div className="aspect-square overflow-hidden bg-neutral-100">
        {/* Plain <img> so any image URL works without extra config */}
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover"
          loading="lazy"
        />
      </div>
      <div className="p-5">
        <div className="flex items-center justify-between text-xs text-neutral-500">
          <span>{product.platform}</span>
          <span>★ {product.rating}</span>
        </div>
        <h3 className="mt-2 text-lg font-semibold leading-snug">{product.name}</h3>
        <p className="mt-1 line-clamp-2 text-sm text-neutral-500">{product.description}</p>
        <div className="mt-4 flex items-center justify-between">
          <span className="font-semibold">{product.price}</span>
          <span className="text-sm font-medium group-hover:underline">View deal →</span>
        </div>
      </div>
    </Link>
  );
}
