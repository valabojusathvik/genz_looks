export const navLinks = [
  { label: "Home", href: "/" },
  { label: "Finds", href: "/#finds" },
  { label: "Channel", href: "https://www.youtube.com" }, // TODO: your channel URL
  { label: "About", href: "/#about" },
];
