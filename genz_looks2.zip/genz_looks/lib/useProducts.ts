"use client";

import { useEffect, useState } from "react";
import { products as sampleProducts, type Product } from "@/data/products";

const KEY = "genz_looks_products";

// Sample products + products added from /admin (saved in this browser).
export function useProducts() {
  const [added, setAdded] = useState<Product[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setAdded(JSON.parse(raw) as Product[]);
    } catch {}
    setReady(true);
  }, []);

  function addProduct(data: Omit<Product, "id">): Product {
    const product: Product = { ...data, id: Date.now() };
    const next = [product, ...added];
    setAdded(next);
    try {
      localStorage.setItem(KEY, JSON.stringify(next));
    } catch {}
    return product;
  }

  return { products: [...added, ...sampleProducts], ready, addProduct };
}
