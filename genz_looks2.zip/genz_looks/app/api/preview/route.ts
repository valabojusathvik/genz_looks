import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const ALLOWED = ["amazon.", "amzn.", "flipkart.", "fkrt.", "meesho."];

function meta(html: string, keys: string[]): string {
  for (const key of keys) {
    const a = new RegExp(
      `<meta[^>]+(?:property|name|itemprop)=["']${key}["'][^>]*content=["']([^"']*)["']`,
      "i"
    ).exec(html);
    const b = new RegExp(
      `<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name|itemprop)=["']${key}["']`,
      "i"
    ).exec(html);
    const found = (a && a[1]) || (b && b[1]);
    if (found) return found.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim();
  }
  return "";
}

export async function GET(req: Request) {
  const target = new URL(req.url).searchParams.get("url") || "";

  let url: URL;
  try {
    url = new URL(target);
  } catch {
    return NextResponse.json({ error: "Invalid link." }, { status: 400 });
  }
  if (!["http:", "https:"].includes(url.protocol) || !ALLOWED.some((d) => url.hostname.includes(d))) {
    return NextResponse.json({ error: "Only Amazon, Flipkart and Meesho links are supported." }, { status: 400 });
  }

  try {
    const res = await fetch(url.toString(), {
      redirect: "follow",
      signal: AbortSignal.timeout(8000),
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
        "Accept-Language": "en-IN,en;q=0.9",
      },
    });
    const html = (await res.text()).slice(0, 600000);

    const host = new URL(res.url).hostname;
    const platform = host.includes("flipkart") || host.includes("fkrt")
      ? "Flipkart"
      : host.includes("meesho")
      ? "Meesho"
      : "Amazon";

    const title =
      meta(html, ["og:title", "twitter:title"]) ||
      (/<title[^>]*>([^<]*)<\/title>/i.exec(html)?.[1] ?? "").trim();
    const image = meta(html, ["og:image", "twitter:image"]);
    const description = meta(html, ["og:description", "description"]);
    const priceRaw =
      meta(html, ["product:price:amount", "og:price:amount", "price"]) ||
      (/"price"\s*:\s*"?([\d.,]+)"?/i.exec(html)?.[1] ?? "");
    const rating = /"ratingValue"\s*:\s*"?([\d.]+)"?/i.exec(html)?.[1] ?? "";

    const blocked = /captcha|robot check|access denied/i.test(title) || (!title && !image);

    return NextResponse.json({
      platform,
      title: blocked ? "" : title,
      image: blocked ? "" : image,
      description: blocked ? "" : description,
      price: blocked || !priceRaw ? "" : `₹${priceRaw}`,
      rating: blocked ? "" : rating,
      blocked,
    });
  } catch {
    return NextResponse.json({ error: "Could not open that link." }, { status: 502 });
  }
}
