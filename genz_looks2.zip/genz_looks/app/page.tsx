"use client";

import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import { useProducts } from "@/lib/useProducts";

export default function HomePage() {
  const { products } = useProducts();

  return (
    <>
      <section className="py-20 sm:py-28">
        <p className="text-xs font-medium tracking-widest text-accent">PRODUCT DISCOVERY</p>
        <h1 className="mt-4 text-5xl font-bold tracking-tight sm:text-7xl">
          Things worth buying.
        </h1>
        <p className="mt-5 max-w-md text-lg text-neutral-500">
          Simple finds, useful products, and things worth discovering.
        </p>
        <a
          href="#finds"
          className="mt-8 inline-block rounded-full bg-black px-6 py-3 text-sm font-medium text-white transition hover:bg-neutral-800"
        >
          Explore finds →
        </a>
      </section>

      <section id="finds" className="scroll-mt-20">
        <h2 className="text-3xl font-bold tracking-tight">Latest Finds</h2>
        <p className="mt-2 text-neutral-500">
          Products I&apos;ve discovered and think are worth a look.
        </p>
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      <section id="about" className="mt-24 scroll-mt-20 max-w-xl">
        <h2 className="text-3xl font-bold tracking-tight">About</h2>
        <p className="mt-2 text-neutral-500">
          genz_looks is where I collect the products I recommend on my YouTube and Instagram.
          Every find links to the store, so you can check the details and decide for yourself.
        </p>
        <Link href="/admin" className="mt-4 inline-block text-xs text-neutral-400 hover:text-black">
          Admin
        </Link>
      </section>
    </>
  );
}
