"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useProducts } from "@/lib/useProducts";

export default function ProductPage() {
  const { id } = useParams<{ id: string }>();
  const { products, ready } = useProducts();
  const product = products.find((p) => String(p.id) === id);

  // Wait for saved products to load before deciding it's missing
  if (!product && !ready) return <div className="py-20" />;

  if (!product) {
    return (
      <div className="py-24">
        <h1 className="text-3xl font-bold tracking-tight">Product not found</h1>
        <Link
          href="/"
          className="mt-6 inline-block rounded-full bg-black px-6 py-3 text-sm font-medium text-white hover:bg-neutral-800"
        >
          ← Back to Home
        </Link>
      </div>
    );
  }

  return (
    <div className="py-10 sm:py-16">
      <Link href="/" className="text-sm text-neutral-500 hover:text-black">
        ← Back
      </Link>
      <div className="mt-6 grid gap-10 md:grid-cols-2">
        <div className="aspect-square overflow-hidden rounded-card border border-black/5 bg-neutral-100">
          <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
        </div>
        <div className="flex flex-col justify-center">
          <p className="text-sm text-neutral-500">{product.platform}</p>
          <h1 className="mt-2 text-4xl font-bold tracking-tight">{product.name}</h1>
          <p className="mt-4 text-neutral-500">{product.description}</p>
          <div className="mt-6 flex items-center gap-4">
            <span className="text-2xl font-semibold">{product.price}</span>
            <span className="text-sm text-neutral-500">★ {product.rating}</span>
          </div>
          <a
            href={product.affiliateUrl}
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="mt-8 inline-block rounded-full bg-black px-6 py-4 text-center font-medium text-white transition hover:bg-neutral-800"
          >
            View on {product.platform} →
          </a>
        </div>
      </div>
    </div>
  );
}
