export type Platform = "Amazon" | "Flipkart" | "Meesho";

export type Product = {
  id: number;
  name: string;
  price: string;
  platform: Platform;
  rating: number;
  image: string;
  description: string;
  affiliateUrl: string;
};

// SAMPLE PRODUCTS - replace these with your own.
// The affiliateUrl values are PLACEHOLDERS, not real affiliate links.
export const products: Product[] = [
  {
    id: 1,
    name: "Wireless Earbuds",
    price: "₹999",
    platform: "Amazon",
    rating: 4.5,
    image: "https://placehold.co/800x800/f1f1ee/999?text=Sample+Product+1",
    description: "A simple everyday pair of wireless earbuds.",
    affiliateUrl: "https://example.com/placeholder-amazon-link",
  },
  {
    id: 2,
    name: "Minimal Desk Lamp",
    price: "₹1,499",
    platform: "Flipkart",
    rating: 4.3,
    image: "https://placehold.co/800x800/f1f1ee/999?text=Sample+Product+2",
    description: "A clean, dimmable lamp for your desk or bedside.",
    affiliateUrl: "https://example.com/placeholder-flipkart-link",
  },
  {
    id: 3,
    name: "Everyday Tote Bag",
    price: "₹599",
    platform: "Meesho",
    rating: 4.1,
    image: "https://placehold.co/800x800/f1f1ee/999?text=Sample+Product+3",
    description: "A roomy canvas tote that goes with everything.",
    affiliateUrl: "https://example.com/placeholder-meesho-link",
  },
  {
    id: 4,
    name: "Portable Phone Stand",
    price: "₹349",
    platform: "Amazon",
    rating: 4.4,
    image: "https://placehold.co/800x800/f1f1ee/999?text=Sample+Product+4",
    description: "A foldable stand that fits in your pocket.",
    affiliateUrl: "https://example.com/placeholder-amazon-link-2",
  },
];
